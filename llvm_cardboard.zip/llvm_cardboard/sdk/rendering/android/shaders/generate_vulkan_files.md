# Generate Vulkan header files for each shader

To generate shader header files please refer to the [developer guide](https://developers.google.com/cardboard/develop/c/vulkan).
